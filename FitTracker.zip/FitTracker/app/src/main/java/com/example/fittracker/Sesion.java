package com.example.fittracker;

public class Sesion {

    private String entrenamiento;
    private String intensidad;
    private float esfuerzo;

    public Sesion(String entrenamiento, String intensidad, float esfuerzo) {
        this.entrenamiento = entrenamiento;
        this.intensidad = intensidad;
        this.esfuerzo = esfuerzo;
    }

    public String getEntrenamiento() {
        return entrenamiento;
    }

    public String getIntensidad() {
        return intensidad;
    }

    public float getEsfuerzo() {
        return esfuerzo;
    }
}