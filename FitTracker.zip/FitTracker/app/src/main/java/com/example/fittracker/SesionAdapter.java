package com.example.fittracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SesionAdapter extends RecyclerView.Adapter<SesionAdapter.SesionViewHolder> {

    private List<Sesion> listaSesiones;

    public SesionAdapter(List<Sesion> listaSesiones) {
        this.listaSesiones = listaSesiones;
    }

    @NonNull
    @Override
    public SesionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sesion, parent, false);

        return new SesionViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull SesionViewHolder holder, int position) {

        Sesion sesion = listaSesiones.get(position);

        holder.txtEntrenamiento.setText(
                "Entrenamiento: " + sesion.getEntrenamiento()
        );

        holder.txtIntensidad.setText(
                "Intensidad: " + sesion.getIntensidad()
        );

        holder.txtEsfuerzo.setText(
                "Esfuerzo: " + sesion.getEsfuerzo() + " estrellas"
        );
    }

    @Override
    public int getItemCount() {
        return listaSesiones.size();
    }

    public static class SesionViewHolder extends RecyclerView.ViewHolder {

        TextView txtEntrenamiento;
        TextView txtIntensidad;
        TextView txtEsfuerzo;

        public SesionViewHolder(@NonNull View itemView) {
            super(itemView);

            txtEntrenamiento =
                    itemView.findViewById(R.id.txtEntrenamiento);

            txtIntensidad =
                    itemView.findViewById(R.id.txtIntensidad);

            txtEsfuerzo =
                    itemView.findViewById(R.id.txtEsfuerzo);
        }
    }
}