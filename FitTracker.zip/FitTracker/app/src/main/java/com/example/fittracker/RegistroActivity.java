package com.example.fittracker;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroActivity extends AppCompatActivity {

    Spinner spinnerEntrenamiento;
    RadioGroup radioGroupIntensidad;
    CheckBox checkCalentamiento;
    CheckBox checkHidratacion;
    CheckBox checkEstiramiento;
    ProgressBar progressMeta;
    RatingBar ratingEsfuerzo;
    Button btnRegistrar;
    RecyclerView recyclerSesiones;
    SesionAdapter adapter;
    List<Sesion> listaSesiones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        recyclerSesiones = findViewById(R.id.recyclerSesiones);

        listaSesiones = new ArrayList<>();

        adapter = new SesionAdapter(listaSesiones);

        recyclerSesiones.setLayoutManager(new LinearLayoutManager(this));

        recyclerSesiones.setAdapter(adapter);

        spinnerEntrenamiento = findViewById(R.id.spinnerEntrenamiento);
        radioGroupIntensidad = findViewById(R.id.radioGroupIntensidad);
        checkCalentamiento = findViewById(R.id.checkCalentamiento);
        checkHidratacion = findViewById(R.id.checkHidratacion);
        checkEstiramiento = findViewById(R.id.checkEstiramiento);
        progressMeta = findViewById(R.id.progressMeta);
        ratingEsfuerzo = findViewById(R.id.ratingEsfuerzo);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        btnRegistrar.setOnClickListener(v -> {

            String entrenamiento =
                    spinnerEntrenamiento.getSelectedItem().toString();

            String intensidad = "No seleccionada";

            int seleccionado = radioGroupIntensidad.getCheckedRadioButtonId();

            if (seleccionado == R.id.radioBaja) {
                intensidad = "Baja";
            } else if (seleccionado == R.id.radioMedia) {
                intensidad = "Media";
            } else if (seleccionado == R.id.radioAlta) {
                intensidad = "Alta";
            }

            boolean calentamiento = checkCalentamiento.isChecked();
            boolean hidratacion = checkHidratacion.isChecked();
            boolean estiramiento = checkEstiramiento.isChecked();

            float esfuerzo = ratingEsfuerzo.getRating();

            Sesion nuevaSesion = new Sesion(
                    entrenamiento,
                    intensidad,
                    esfuerzo
            );

            listaSesiones.add(nuevaSesion);

            adapter.notifyDataSetChanged();

            Toast.makeText(
                    this,
                    "Actividad registrada: " + entrenamiento +
                            " - " + intensidad +
                            " - " + esfuerzo + " estrellas",
                    Toast.LENGTH_LONG
            ).show();
        });
    }
}